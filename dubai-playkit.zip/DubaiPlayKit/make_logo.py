import math
# Tek bir "B" harfi (0..100 kutusunda). Dört kopya farklı yönlere çevrilerek amblem oluşur.
OUTER=[("M",20,10),("L",50,10),("A",18,50,46),("L",54,46),("A",22,54,90),("L",20,90),("Z",)]
HOLE1=[("M",32,22),("L",50,22),("A",6,50,34),("L",32,34),("Z",)]
HOLE2=[("M",32,58),("L",54,58),("A",8,54,74),("L",32,74),("Z",)]
S=0.27
CENTERS=[(42.5,42.5),(65.5,42.5),(65.5,65.5),(42.5,65.5)]
COLORS=["#19C3C0","#FF6B4A","#FFC93C","#8B5CF6"]

def tf(x,y,k,c,off):
    px,py=(x-48)*S,(y-50)*S
    for _ in range(k):
        px,py=-py,px
    return px+c[0]-off, py+c[1]-off

def shape(cmds,k,c,off):
    d=[];pts=[];prev=None
    for cm in cmds:
        t=cm[0]
        if t in "ML":
            x,y=tf(cm[1],cm[2],k,c,off)
            d.append("%s%.2f,%.2f"%(t,x,y)); pts.append((x,y)); prev=(x,y)
        elif t=="A":
            r=cm[1]*S
            x,y=tf(cm[2],cm[3],k,c,off)
            d.append("A%.2f,%.2f 0 0 1 %.2f,%.2f"%(r,r,x,y))
            cx,cy=(prev[0]+x)/2,(prev[1]+y)/2
            a0=math.atan2(prev[1]-cy,prev[0]-cx)
            for i in range(1,24):
                a=a0+math.pi*i/24
                pts.append((cx+r*math.cos(a),cy+r*math.sin(a)))
            pts.append((x,y)); prev=(x,y)
        else:
            d.append("Z")
    return " ".join(d),pts

def build(off,vp,path):
    out=['<?xml version="1.0" encoding="utf-8"?>',
    '<vector xmlns:android="http://schemas.android.com/apk/res/android"',
    '    android:width="%ddp" android:height="%ddp"'%(vp,vp),
    '    android:viewportWidth="%d" android:viewportHeight="%d">'%(vp,vp)]
    polys=[]
    for i in range(4):
        parts=[];pp=[]
        for cmds in (OUTER,HOLE1,HOLE2):
            d,p=shape(cmds,i,CENTERS[i],off); parts.append(d); pp.append(p)
        out.append('    <path android:fillColor="%s" android:fillType="evenOdd"\n        android:pathData="%s" />'%(COLORS[i]," ".join(parts)))
        polys.append((COLORS[i],pp))
    out.append('</vector>')
    open(path,"w").write("\n".join(out)+"\n")
    return polys

build(0,108,"app/src/main/res/drawable/ic_launcher_foreground.xml")
polys=build(24,60,"app/src/main/res/drawable/logo_emblem.xml")

try:
    from PIL import Image,ImageDraw
    N=2048;sc=N/60.0
    img=Image.new("RGB",(N,N),"#0B1B3A");dr=ImageDraw.Draw(img)
    # 60'lık görünüm kutusu: ortalamak için kenar boşluğu bırak
    pad=0.0
    for col,(o,h1,h2) in polys:
        dr.polygon([(x*sc,y*sc) for x,y in o],fill=col)
        dr.polygon([(x*sc,y*sc) for x,y in h1],fill="#0B1B3A")
        dr.polygon([(x*sc,y*sc) for x,y in h2],fill="#0B1B3A")
    img.resize((512,512),Image.LANCZOS).save("store/icon-512.png")
    print("PNG hazir")
except Exception as e:
    print("PNG uretilemedi:",e)
