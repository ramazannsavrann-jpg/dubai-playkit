# DUBAI PlayKit — Your Pocket Game Toolkit

Çevrimdışı çalışan, reklamsız, 22 oyun aracı içeren Android uygulaması (Kotlin + Jetpack Compose).

## Araçlar (22)
Şans: şişe çevirme, yazı tura, renk çarkı, isim çarkı, rastgele sayı, evet/hayır, harf seçici.
Masa: zar, çok yüzlü zar, iskambil, domino, XOX. Parti: taş-kâğıt-makas, gizli seçim, tek-çift/parmak, rastgele görev.
Oyuncular: puan sayacı, takım oluşturucu, sıralayıcı, eşleştirme. Zamanlayıcı: kum saati geri sayım. Kendi oyununu oluştur.

## Teknik bilgiler
- Uygulama kimliği: `com.dubaiplaykit.app` — sürüm 1.0.0 (versionCode 1)
- minSdk 26 (Android 8.0), targetSdk 34
- İzin yok, reklam SDK'sı yok, internet kullanımı yok. Veriler cihazda (SharedPreferences) saklanır.
- Launcher ikonu: adaptive icon (`mipmap-anydpi-v26`) + vektör dört-B amblemi (`drawable/ic_launcher_foreground.xml`).
- `make_logo.py`: amblemi üretir (yeniden üretmek için `python3 make_logo.py`). `store/icon-512.png`: Play Store için 512 px ikon.

## Derleme
Gradle wrapper dosyası eklenmedi; GitHub Actions Gradle 8.7'yi kendisi kurar (`.github/workflows/build.yml`).
Bilgisayarda derlemek için: Android Studio ile aç veya Gradle 8.7 + JDK 17 ile `gradle assembleDebug`.
Çıktı: `app/build/outputs/apk/debug/app-debug.apk`.

## Google Play için
İmzalı AAB için bir upload keystore oluşturup `gradle bundleRelease` çalıştırmak gerekir (anahtarı sohbete yazma; GitHub Secrets kullan).
