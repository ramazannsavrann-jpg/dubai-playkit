package com.dubaiplaykit.app

import com.dubaiplaykit.app.logic.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LogicTest {

    @Test
    fun diceStayInRange() {
        repeat(2000) { assertTrue(Dice.roll(6) in 1..6) }
        for (s in Dice.polySides) repeat(500) { assertTrue(Dice.roll(s) in 1..s) }
    }

    @Test
    fun rollManyReturnsRequestedCount() {
        assertEquals(1, Dice.rollMany(1, 6).size)
        assertEquals(20, Dice.rollMany(20, 20).size)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rollManyRejectsTooMany() {
        Dice.rollMany(21, 6)
    }

    @Test
    fun coinProducesOnlyTwoResults() {
        val seen = (1..300).map { Coin.flip() }.toSet()
        assertEquals(setOf(CoinSide.YAZI, CoinSide.TURA), seen)
    }

    @Test
    fun rangeParsingValidatesInput() {
        assertNotNull(RandomRange.parse("a", "5").error)
        assertNotNull(RandomRange.parse("10", "5").error)
        assertNotNull(RandomRange.parse("0", "2000000000").error)
        assertNull(RandomRange.parse("1", "100").error)
        repeat(500) {
            val v = RandomRange.pick(-3, 3)
            assertTrue(v in -3..3)
        }
        assertEquals(7, RandomRange.pick(7, 7))
    }

    @Test
    fun shuffleBagNeverRepeatsUntilReset() {
        val bag = ShuffleBag((1..10).toList())
        val drawn = (1..10).map { bag.draw()!! }
        assertEquals(10, drawn.toSet().size)
        assertNull(bag.draw())
        bag.reset()
        assertNotNull(bag.draw())
    }

    @Test
    fun shuffleBagWithoutRemovalNeverRunsOut() {
        val bag = ShuffleBag(listOf("a", "b"))
        repeat(50) { assertNotNull(bag.draw(removeDrawn = false)) }
    }

    @Test
    fun deckHas52UniqueCards() {
        val d = Deck.standard()
        assertEquals(52, d.size)
        assertEquals(52, d.toSet().size)
    }

    @Test
    fun dominoSetHas28UniqueTiles() {
        val t = Dominoes.doubleSix()
        assertEquals(28, t.size)
        assertEquals(28, t.toSet().size)
        assertTrue(t.all { it.a in 0..6 && it.b in 0..6 && it.a <= it.b })
    }

    @Test
    fun turkishAlphabetHas29Letters() {
        assertEquals(29, TurkishAlphabet.list.size)
        assertTrue(TurkishAlphabet.list.containsAll(listOf("Ç", "Ğ", "İ", "Ö", "Ş", "Ü")))
    }

    @Test
    fun ticTacToeDetectsWinAndDraw() {
        val win = "XXXOO    ".toList()
        assertEquals(listOf(0, 1, 2), TicTacToe.winningLine(win))
        val diag = "XO OXO  X".toList()
        assertEquals(listOf(0, 4, 8), TicTacToe.winningLine(diag))
        val draw = "XOXXOOOXX".toList()
        assertNull(TicTacToe.winningLine(draw))
        assertTrue(TicTacToe.isFull(draw))
        assertNull(TicTacToe.winningLine("         ".toList()))
    }

    @Test
    fun rockPaperScissorsRules() {
        assertEquals(0, Rps.result(0, 0))
        assertEquals(1, Rps.result(0, 2)) // taş makası yener
        assertEquals(1, Rps.result(1, 0)) // kâğıt taşı yener
        assertEquals(1, Rps.result(2, 1)) // makas kâğıdı yener
        assertEquals(2, Rps.result(2, 0))
    }

    @Test
    fun teamsIncludeEveryoneExactlyOnceAndStayBalanced() {
        val players = (1..11).map { "P$it" }
        for (count in 1..11) {
            val teams = Teams.split(players, count)
            assertEquals(count, teams.size)
            assertEquals(players.toSet(), teams.flatten().toSet())
            assertEquals(players.size, teams.flatten().size)
            val sizes = teams.map { it.size }
            assertTrue(sizes.max() - sizes.min() <= 1)
        }
        assertEquals(4, Teams.teamCountForSize(10, 3))
    }

    @Test
    fun pairingHandlesOddAndEvenPlayers() {
        val even = Pairs.make(listOf("a", "b", "c", "d"))
        assertEquals(2, even.pairs.size)
        assertNull(even.leftOver)
        val odd = Pairs.make(listOf("a", "b", "c", "d", "e"))
        assertEquals(2, odd.pairs.size)
        assertNotNull(odd.leftOver)
        val all = odd.pairs.flatMap { listOf(it.first, it.second) } + odd.leftOver!!
        assertEquals(setOf("a", "b", "c", "d", "e"), all.toSet())
        assertEquals(5, all.size)
    }

    @Test
    fun pickerRespectsNoRepeat() {
        val items = listOf("x", "y", "z")
        val used = mutableSetOf<String>()
        repeat(3) {
            val p = Picker.pick(items, used, true)!!
            assertTrue(p !in used)
            used.add(p)
        }
        assertNull(Picker.pick(items, used, true))
        assertNotNull(Picker.pick(items, used, false))
    }

    @Test
    fun wheelStopsOnChosenSlice() {
        for (n in 2..12) for (idx in 0 until n) for (cur in listOf(0f, 123.4f, 1000f)) {
            repeat(30) {
                val r = WheelMath.targetRotation(cur, idx, n)
                assertEquals(idx, WheelMath.indexAt(r, n))
            }
        }
    }

    @Test
    fun codecRoundTripsListsAndGames() {
        val list = listOf("Ayşe", "Çağrı, Öz", "İpek")
        assertEquals(list, Codec.decodeList(Codec.encodeList(list)))
        assertEquals(emptyList<String>(), Codec.decodeList(Codec.encodeList(emptyList())))
        val games = listOf(CustomGame("Akşam", listOf("a", "b")), CustomGame("Görevler", listOf("x")))
        assertEquals(games, Codec.decodeGames(Codec.encodeGames(games)))
        assertEquals("abc", Codec.clean("a\u0001b\u0002c"))
    }

    @Test
    fun countdownUsesRealTime() {
        assertEquals(0L, Countdown.remaining(1000L, 5000L))
        assertEquals(4000L, Countdown.remaining(5000L, 1000L))
        assertEquals("00:30", Countdown.format(30_000L))
        assertEquals("01:05", Countdown.format(65_000L))
        assertEquals("00:01", Countdown.format(1L))
    }

    @Test
    fun diceAlwaysFitScreenWidth() {
        for (avail in listOf(288f, 328f, 360f, 420f)) {
            for (n in 1..20) {
                val p = DiceLayout.plan(n, avail)
                val used = p.perRow * p.sizeDp + 14f * (p.perRow - 1)
                assertTrue("n=$n avail=$avail used=$used", used <= avail + 0.01f)
                assertTrue(p.sizeDp >= 40f)
            }
        }
    }

    @Test
    fun fewDiceAreBig() {
        assertTrue(DiceLayout.plan(1, 328f).sizeDp >= 170f)
        assertTrue(DiceLayout.plan(2, 328f).sizeDp >= 140f)
        assertEquals(2, DiceLayout.plan(4, 328f).perRow)
    }
}
