package com.dubaiplaykit.app.data

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import com.dubaiplaykit.app.logic.Codec
import com.dubaiplaykit.app.logic.CustomGame

/** Tüm kullanıcı verileri yalnızca cihazdaki SharedPreferences içinde saklanır. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("dubai_playkit_prefs", Context.MODE_PRIVATE)

    fun getList(key: String, default: List<String> = emptyList()): List<String> {
        val s = sp.getString(key, null) ?: return default
        return Codec.decodeList(s)
    }

    fun putList(key: String, list: List<String>) {
        sp.edit().putString(key, Codec.encodeList(list)).apply()
    }

    fun getBool(key: String, default: Boolean): Boolean = sp.getBoolean(key, default)

    fun putBool(key: String, value: Boolean) {
        sp.edit().putBoolean(key, value).apply()
    }

    fun getString(key: String, default: String): String = sp.getString(key, default) ?: default

    fun putString(key: String, value: String) {
        sp.edit().putString(key, value).apply()
    }

    fun getGames(): List<CustomGame> {
        val s = sp.getString("custom_games", null) ?: return emptyList()
        return Codec.decodeGames(s)
    }

    fun putGames(games: List<CustomGame>) {
        sp.edit().putString("custom_games", Codec.encodeGames(games)).apply()
    }
}

val LocalPrefs = staticCompositionLocalOf<Prefs> { error("Prefs sağlanmadı") }

class PersistentStringList(private val prefs: Prefs, private val key: String, default: List<String>) {
    val items = mutableStateListOf<String>().apply { addAll(prefs.getList(key, default)) }

    private fun save() {
        prefs.putList(key, items.toList())
    }

    fun add(s: String) {
        val t = s.trim()
        if (t.isNotEmpty()) {
            items.add(t)
            save()
        }
    }

    fun update(i: Int, s: String) {
        val t = s.trim()
        if (i in items.indices && t.isNotEmpty()) {
            items[i] = t
            save()
        }
    }

    fun removeAt(i: Int) {
        if (i in items.indices) {
            items.removeAt(i)
            save()
        }
    }
}

@Composable
fun rememberPersistentList(key: String, default: List<String> = emptyList()): PersistentStringList {
    val prefs = LocalPrefs.current
    return remember(key) { PersistentStringList(prefs, key, default) }
}
