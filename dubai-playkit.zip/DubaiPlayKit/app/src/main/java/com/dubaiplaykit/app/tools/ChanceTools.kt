package com.dubaiplaykit.app.tools

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dubaiplaykit.app.data.rememberPersistentList
import com.dubaiplaykit.app.logic.*
import com.dubaiplaykit.app.ui.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

@Composable
fun BottleTool() {
    val rotation = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var spinning by remember { mutableStateOf(false) }
    val spin: () -> Unit = {
        if (!spinning) {
            spinning = true
            scope.launch {
                val target = rotation.value + 1440f + Random.nextFloat() * 360f
                rotation.animateTo(target, tween(3500, easing = FastOutSlowInEasing))
                rotation.snapTo(rotation.value % 360f)
                spinning = false
            }
        }
    }
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(24.dp))
            .background(NavyLight)
            .clickable(onClick = spin),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            Modifier
                .fillMaxSize(0.85f)
                .graphicsLayer { rotationZ = rotation.value }
        ) {
            val w = this.size.width
            val h = this.size.height
            drawRoundRect(Turquoise, Offset(w * 0.44f, h * 0.06f), Size(w * 0.12f, h * 0.34f), CornerRadius(12f, 12f))
            drawRoundRect(Coral, Offset(w * 0.42f, h * 0.04f), Size(w * 0.16f, h * 0.06f), CornerRadius(8f, 8f))
            drawRoundRect(Turquoise, Offset(w * 0.34f, h * 0.36f), Size(w * 0.32f, h * 0.56f), CornerRadius(w * 0.1f, w * 0.1f))
            drawRoundRect(Sun, Offset(w * 0.37f, h * 0.55f), Size(w * 0.26f, h * 0.16f), CornerRadius(8f, 8f))
        }
    }
    Text("Şişenin ağzı kime dönerse o seçilir!", color = Muted, textAlign = TextAlign.Center)
    BigButton("ŞİŞEYİ ÇEVİR", enabled = !spinning, onClick = spin)
}

@Composable
fun CoinTool() {
    val angle = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var yazi by remember { mutableIntStateOf(0) }
    var tura by remember { mutableIntStateOf(0) }
    var last by remember { mutableStateOf<CoinSide?>(null) }
    val norm = ((angle.value % 360f) + 360f) % 360f
    val showFront = norm < 90f || norm > 270f

    Box(
        Modifier
            .size(210.dp)
            .graphicsLayer {
                rotationY = angle.value
                cameraDistance = 16f * density
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color(0xFFFFE082), Sun, Color(0xFFE0A800))))
                .border(6.dp, Color(0xFFB8860B), CircleShape)
                .graphicsLayer { rotationY = if (showFront) 0f else 180f },
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (showFront) "YAZI" else "TURA",
                color = Color(0xFF6B4A00),
                fontSize = 40.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }
    }
    val l = last
    if (l != null && !busy) ResultCard(l.label, if (l == CoinSide.YAZI) Sun else Coral)
    BigButton(if (last == null) "PARAYI AT" else "TEKRAR AT", enabled = !busy) {
        busy = true
        val result = Coin.flip()
        scope.launch {
            val current = ((angle.value % 360f) + 360f) % 360f
            val wanted = if (result == CoinSide.YAZI) 0f else 180f
            val extra = ((wanted - current) % 360f + 360f) % 360f
            angle.animateTo(angle.value + 1440f + extra, tween(1800, easing = FastOutSlowInEasing))
            angle.snapTo(wanted)
            if (result == CoinSide.YAZI) yazi++ else tura++
            last = result
            busy = false
        }
    }
    Panel {
        Text("İstatistik", color = Color.White, fontWeight = FontWeight.Bold)
        Text("YAZI: $yazi   |   TURA: $tura   |   Toplam: ${yazi + tura}", color = Muted)
        SoftButton("Sayaçları sıfırla") { yazi = 0; tura = 0; last = null }
    }
}

@Composable
fun ColorWheelTool() {
    val names = listOf("Kırmızı", "Turuncu", "Sarı", "Yeşil", "Turkuaz", "Mavi", "Mor", "Pembe")
    val colors = listOf(
        Color(0xFFE53935), Color(0xFFFB8C00), Color(0xFFFDD835), Color(0xFF43A047),
        Color(0xFF00ACC1), Color(0xFF1E88E5), Color(0xFF8E24AA), Color(0xFFEC407A)
    )
    SpinWheel(names, colors, "RENK ÇEVİR")
}

@Composable
fun NameWheelTool() {
    val list = rememberPersistentList("wheel_items", listOf("Ayşe", "Mehmet", "Elif", "Can"))
    val excluded = remember { mutableStateListOf<String>() }
    var removeAfter by remember { mutableStateOf(false) }
    val active = list.items.filter { it !in excluded }
    SpinWheel(active, WheelPalette, "ÇARKI ÇEVİR") { idx ->
        if (removeAfter && idx in active.indices) excluded.add(active[idx])
    }
    SwitchRow("Seçileni sonraki turlardan çıkar", removeAfter) { removeAfter = it }
    if (excluded.isNotEmpty()) {
        SoftButton("Çıkarılanları geri al (${excluded.size})") { excluded.clear() }
    }
    Panel {
        Text("İsimler / seçenekler", color = Color.White, fontWeight = FontWeight.Bold)
        ListEditor(list, "Yeni seçenek")
    }
}

@Composable
fun RandomNumberTool() {
    var minText by remember { mutableStateOf("1") }
    var maxText by remember { mutableStateOf("100") }
    var result by remember { mutableStateOf<Int?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        AppField(minText, { minText = it }, "En küçük", Modifier.weight(1f), numeric = true)
        AppField(maxText, { maxText = it }, "En büyük", Modifier.weight(1f), numeric = true)
    }
    ErrorText(error)
    val r = result
    if (r != null) ResultCard(r.toString())
    BigButton("SAYI ÜRET") {
        val p = RandomRange.parse(minText, maxText)
        if (p.error != null) {
            error = p.error
            result = null
        } else {
            error = null
            result = RandomRange.pick(p.min, p.max)
        }
    }
}

@Composable
fun YesNoTool() {
    var shown by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val scale by animateFloatAsState(if (busy) 0.94f else 1f, label = "yesno")
    val bg = when (shown) {
        "EVET" -> Good
        "HAYIR" -> Bad
        else -> NavyLight
    }
    Box(
        Modifier
            .fillMaxWidth()
            .height(230.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(28.dp))
            .background(bg)
            .clickable(enabled = !busy) {
                busy = true
                scope.launch {
                    val finalAnswer = if (Random.nextBoolean()) "EVET" else "HAYIR"
                    repeat(10) { i ->
                        shown = if (i % 2 == 0) "EVET" else "HAYIR"
                        delay(70)
                    }
                    shown = finalAnswer
                    busy = false
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(shown ?: "Dokun!", color = Color.White, fontSize = 52.sp, fontWeight = FontWeight.ExtraBold)
    }
    Text("Karar veremiyorsan kutuya dokun.", color = Muted)
}

@Composable
fun LetterTool() {
    val bag = remember { mutableStateOf(ShuffleBag(TurkishAlphabet.list)) }
    val used = remember { mutableStateListOf<String>() }
    var current by remember { mutableStateOf<String?>(null) }
    var noRepeat by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var finished by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val total = TurkishAlphabet.list.size

    fun resetAll() {
        bag.value = ShuffleBag(TurkishAlphabet.list)
        used.clear()
        current = null
        finished = false
    }

    Box(
        Modifier.size(180.dp).clip(RoundedCornerShape(32.dp)).background(Purple),
        contentAlignment = Alignment.Center
    ) {
        Text(current ?: "?", color = Color.White, fontSize = 96.sp, fontWeight = FontWeight.ExtraBold)
    }
    if (finished) {
        Text("Bütün harfler çıktı! Yeniden başlatabilirsin.", color = Sun, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
    if (noRepeat) Text("Kalan harf: ${total - used.size} / $total", color = Muted)
    BigButton("HARF SEÇ", enabled = !busy && !finished) {
        busy = true
        scope.launch {
            val letter = bag.value.draw(removeDrawn = noRepeat)
            if (letter == null) {
                finished = true
            } else {
                repeat(8) {
                    current = TurkishAlphabet.list[Random.nextInt(total)]
                    delay(60)
                }
                current = letter
                used.add(letter)
                if (noRepeat && used.size >= total) finished = true
            }
            busy = false
        }
    }
    SwitchRow("Çıkan harfler tekrar seçilmesin", noRepeat) {
        noRepeat = it
        resetAll()
    }
    SoftButton("Yeniden başlat") { resetAll() }
    if (used.isNotEmpty()) {
        Panel {
            Text("Çıkan harfler", color = Color.White, fontWeight = FontWeight.Bold)
            Text(used.joinToString("  "), color = Sun, fontSize = 20.sp)
        }
    }
}
