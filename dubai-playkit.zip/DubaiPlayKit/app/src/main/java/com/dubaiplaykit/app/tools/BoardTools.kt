package com.dubaiplaykit.app.tools

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dubaiplaykit.app.logic.*
import com.dubaiplaykit.app.ui.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

@Composable
private fun DiceRoller(sides: Int, count: Int, showTotalSwitch: Boolean) {
    var values by remember { mutableStateOf<List<Int>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var showTotal by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()
    if (values.isNotEmpty()) {
        DiceGrid(values, sides)
        if (!showTotalSwitch || showTotal) {
            ResultCard("Toplam: ${values.sum()}", Sun)
        }
    }
    BigButton(if (values.isEmpty()) "ZARLARI AT" else "TEKRAR AT", enabled = !busy) {
        busy = true
        scope.launch {
            val finalValues = Dice.rollMany(count, sides)
            repeat(8) {
                values = List(count) { Random.nextInt(1, sides + 1) }
                delay(60)
            }
            values = finalValues
            busy = false
        }
    }
    if (showTotalSwitch) SwitchRow("Toplamı göster", showTotal) { showTotal = it }
}

@Composable
fun DiceTool() {
    var count by remember { mutableIntStateOf(2) }
    Panel {
        Text("Zar sayısı: $count", color = Color.White, fontWeight = FontWeight.Bold)
        Slider(
            value = count.toFloat(),
            onValueChange = { count = it.toInt().coerceIn(1, Dice.MAX_COUNT) },
            valueRange = 1f..20f,
            steps = 18
        )
    }
    DiceRoller(sides = 6, count = count, showTotalSwitch = true)
}

@Composable
fun PolyDiceTool() {
    var sides by remember { mutableIntStateOf(20) }
    var count by remember { mutableIntStateOf(1) }
    Panel {
        Text("Zar tipi", color = Color.White, fontWeight = FontWeight.Bold)
        ChipSelector(Dice.polySides, sides, { "D$it" }) { sides = it }
        Text("Zar sayısı: $count", color = Color.White, fontWeight = FontWeight.Bold)
        Slider(
            value = count.toFloat(),
            onValueChange = { count = it.toInt().coerceIn(1, Dice.MAX_COUNT) },
            valueRange = 1f..20f,
            steps = 18
        )
    }
    key(sides, count) {
        DiceRoller(sides = sides, count = count, showTotalSwitch = false)
    }
}

@Composable
private fun CardBack(w: Dp, h: Dp) {
    Box(
        Modifier
            .size(w, h)
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(listOf(Purple, Coral)))
            .border(3.dp, Color.White, RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text("DUBAI", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun CardFace(card: Card, w: Dp, h: Dp) {
    val c = if (card.isRed) Color(0xFFD32F2F) else Color(0xFF1A1A2E)
    Box(
        Modifier
            .size(w, h)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White)
            .border(2.dp, Color(0xFFCBD5E1), RoundedCornerShape(14.dp))
    ) {
        Text(
            card.rankLabel + "\n" + card.suitSymbol,
            modifier = Modifier.align(Alignment.TopStart).padding(10.dp),
            color = c,
            fontSize = 22.sp,
            lineHeight = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Text(card.suitSymbol, modifier = Modifier.align(Alignment.Center), color = c, fontSize = 76.sp)
    }
}

@Composable
fun CardsTool() {
    val bag = remember { mutableStateOf(ShuffleBag(Deck.standard())) }
    val drawn = remember { mutableStateListOf<Card>() }
    var current by remember { mutableStateOf<Card?>(null) }
    var removeDrawn by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    val flip = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val remaining = 52 - drawn.size
    val deckEmpty = removeDrawn && remaining <= 0

    fun reshuffle() {
        bag.value = ShuffleBag(Deck.standard())
        drawn.clear()
        current = null
    }

    Box(
        Modifier.graphicsLayer {
            rotationY = flip.value
            cameraDistance = 14f * density
        }
    ) {
        val c = current
        if (c != null && flip.value <= 90f) CardFace(c, 160.dp, 230.dp) else CardBack(160.dp, 230.dp)
    }
    if (removeDrawn) {
        Text(
            if (deckEmpty) "Deste bitti! Yeniden karıştır." else "Destede $remaining kart kaldı",
            color = if (deckEmpty) Sun else Muted,
            fontWeight = FontWeight.Bold
        )
    }
    BigButton("KART ÇEK", enabled = !busy && !deckEmpty) {
        val card = bag.value.draw(removeDrawn)
        if (card != null) {
            busy = true
            scope.launch {
                current = card
                drawn.add(card)
                flip.snapTo(180f)
                flip.animateTo(0f, tween(450))
                busy = false
            }
        }
    }
    SoftButton("Desteyi yeniden karıştır", Modifier.fillMaxWidth()) { reshuffle() }
    SwitchRow("Çekilen kartlar desteden çıksın", removeDrawn) {
        removeDrawn = it
        reshuffle()
    }
    if (drawn.isNotEmpty()) {
        Panel {
            Text("Çekilenler (${drawn.size})", color = Color.White, fontWeight = FontWeight.Bold)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                drawn.asReversed().forEach { c ->
                    Box(
                        Modifier.clip(RoundedCornerShape(8.dp)).background(Color.White).padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            c.label,
                            color = if (c.isRed) Color(0xFFD32F2F) else Color(0xFF1A1A2E),
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DominoTile(t: Tile) {
    Row(
        Modifier.clip(RoundedCornerShape(12.dp)).background(Color(0xFFF5F0E1)).padding(6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        PipFace(t.a, 76.dp, Color(0xFFF5F0E1), Navy)
        Box(Modifier.width(3.dp).height(60.dp).background(Navy))
        PipFace(t.b, 76.dp, Color(0xFFF5F0E1), Navy)
    }
}

@Composable
fun DominoTool() {
    val bag = remember { mutableStateOf(ShuffleBag(Dominoes.doubleSix())) }
    val drawn = remember { mutableStateListOf<Tile>() }
    var current by remember { mutableStateOf<Tile?>(null) }
    var removeDrawn by remember { mutableStateOf(true) }
    val total = Dominoes.doubleSix().size
    val remaining = total - drawn.size
    val empty = removeDrawn && remaining <= 0

    fun resetSet() {
        bag.value = ShuffleBag(Dominoes.doubleSix())
        drawn.clear()
        current = null
    }

    val c = current
    if (c != null) DominoTile(c) else Text("Taş çekmek için butona bas", color = Muted)
    if (removeDrawn) {
        Text(
            if (empty) "Bütün taşlar çekildi!" else "Kalan taş: $remaining / $total",
            color = if (empty) Sun else Muted,
            fontWeight = FontWeight.Bold
        )
    }
    BigButton("TAŞ ÇEK", enabled = !empty) {
        val t = bag.value.draw(removeDrawn)
        if (t != null) {
            current = t
            drawn.add(t)
        }
    }
    SoftButton("Seti yeniden başlat", Modifier.fillMaxWidth()) { resetSet() }
    SwitchRow("Çekilen taşlar tekrar gelmesin", removeDrawn) {
        removeDrawn = it
        resetSet()
    }
    if (drawn.isNotEmpty()) {
        Panel {
            Text("Çekilenler", color = Color.White, fontWeight = FontWeight.Bold)
            Text(drawn.joinToString("  ") { "[${it.a}|${it.b}]" }, color = Sun, fontSize = 16.sp)
        }
    }
}

private val rpsEmoji = listOf("✊", "✋", "✌️")
private val rpsName = listOf("Taş", "Kâğıt", "Makas")

@Composable
private fun RpsButtons(onPick: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        for (i in 0..2) {
            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(18.dp))
                    .background(NavyLighter)
                    .clickable { onPick(i) }
                    .padding(vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(rpsEmoji[i], fontSize = 44.sp)
                Text(rpsName[i], color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun RpsTool() {
    var twoPhones by remember { mutableStateOf(false) }
    var phase by remember { mutableIntStateOf(0) } // 0: 1. oyuncu, 1: devir, 2: 2. oyuncu, 3: sonuç
    var p1 by remember { mutableIntStateOf(-1) }
    var p2 by remember { mutableIntStateOf(-1) }
    var score1 by remember { mutableIntStateOf(0) }
    var score2 by remember { mutableIntStateOf(0) }
    var mine by remember { mutableIntStateOf(-1) }
    var revealed by remember { mutableStateOf(false) }

    ChipSelector(listOf(false, true), twoPhones, { if (it) "İki telefon" else "Tek telefon" }) {
        twoPhones = it
        phase = 0; p1 = -1; p2 = -1; mine = -1; revealed = false
    }

    if (!twoPhones) {
        when (phase) {
            0 -> {
                Panel {
                    Text("1. Oyuncu seçimini yapsın", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Diğer oyuncu bakmasın!", color = Muted)
                }
                RpsButtons { p1 = it; phase = 1 }
            }
            1 -> {
                Panel {
                    Text("Seçim gizlendi ✔", color = Good, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Telefonu 2. oyuncuya ver.", color = Color.White)
                }
                BigButton("2. OYUNCU HAZIR") { phase = 2 }
            }
            2 -> {
                Panel {
                    Text("2. Oyuncu seçimini yapsın", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                RpsButtons {
                    p2 = it
                    val r = Rps.result(p1, p2)
                    if (r == 1) score1++ else if (r == 2) score2++
                    phase = 3
                }
            }
            else -> {
                val r = Rps.result(p1, p2)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("1. Oyuncu", color = Muted)
                        Text(rpsEmoji[p1], fontSize = 64.sp)
                        Text(rpsName[p1], color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("2. Oyuncu", color = Muted)
                        Text(rpsEmoji[p2], fontSize = 64.sp)
                        Text(rpsName[p2], color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
                ResultCard(
                    when (r) {
                        0 -> "Berabere!"
                        1 -> "1. Oyuncu kazandı!"
                        else -> "2. Oyuncu kazandı!"
                    },
                    if (r == 0) Sun else Good
                )
                BigButton("YENİ TUR") { phase = 0; p1 = -1; p2 = -1 }
            }
        }
        Text("Skor  1. Oyuncu: $score1   |   2. Oyuncu: $score2", color = Muted)
        SoftButton("Skoru sıfırla") { score1 = 0; score2 = 0 }
    } else {
        Panel {
            Text("Herkes kendi telefonunda seçsin", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Hazır olunca 'Seçimimi göster'e bas ve ekranı karşındakine göster. Sonucu siz belirlersiniz.", color = Muted, fontSize = 14.sp)
        }
        if (mine < 0) {
            RpsButtons { mine = it; revealed = false }
        } else {
            if (revealed) {
                Text(rpsEmoji[mine], fontSize = 120.sp)
                Text(rpsName[mine], color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                SoftButton("Gizle", Modifier.fillMaxWidth()) { revealed = false }
            } else {
                Text("Seçimin gizli ✔", color = Good, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                BigButton("SEÇİMİMİ GÖSTER") { revealed = true }
            }
            SoftButton("Yeni tur", Modifier.fillMaxWidth()) { mine = -1; revealed = false }
        }
    }
}

@Composable
fun XoxTool() {
    val board = remember { mutableStateListOf(' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ') }
    var turn by remember { mutableStateOf('X') }
    var scoreX by remember { mutableIntStateOf(0) }
    var scoreO by remember { mutableIntStateOf(0) }
    var draws by remember { mutableIntStateOf(0) }
    val win = TicTacToe.winningLine(board.toList())
    val full = TicTacToe.isFull(board.toList())
    val over = win != null || full

    ResultCard(
        when {
            win != null -> "${board[win[0]]} kazandı! 🎉"
            full -> "Berabere!"
            else -> "Sıra: $turn"
        },
        if (win != null) Good else if (full) Sun else if (turn == 'X') Coral else Turquoise
    )
    Column(Modifier.widthIn(max = 340.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for (r in 0..2) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (c in 0..2) {
                    val i = r * 3 + c
                    val inWin = win != null && i in win
                    Box(
                        Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (inWin) Sun else NavyLighter)
                            .clickable(enabled = !over && board[i] == ' ') {
                                board[i] = turn
                                val w = TicTacToe.winningLine(board.toList())
                                if (w != null) {
                                    if (turn == 'X') scoreX++ else scoreO++
                                } else if (TicTacToe.isFull(board.toList())) {
                                    draws++
                                } else {
                                    turn = if (turn == 'X') 'O' else 'X'
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (board[i] == ' ') "" else board[i].toString(),
                            color = if (inWin) Navy else if (board[i] == 'X') Coral else Turquoise,
                            fontSize = 48.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }
    BigButton("YENİ OYUN") {
        for (i in 0..8) board[i] = ' '
        turn = 'X'
    }
    Text("X: $scoreX   |   O: $scoreO   |   Beraberlik: $draws", color = Muted)
    SoftButton("Skoru sıfırla") { scoreX = 0; scoreO = 0; draws = 0 }
}
