package com.dubaiplaykit.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.sp
import com.dubaiplaykit.app.data.LocalPrefs
import com.dubaiplaykit.app.data.Prefs
import com.dubaiplaykit.app.tools.AllTools
import com.dubaiplaykit.app.tools.Cats
import com.dubaiplaykit.app.ui.AppBackground
import com.dubaiplaykit.app.ui.NavyLight
import com.dubaiplaykit.app.ui.PlayKitTheme
import com.dubaiplaykit.app.ui.ToolScaffold

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(applicationContext)
        setContent {
            PlayKitTheme {
                CompositionLocalProvider(LocalPrefs provides prefs) {
                    PlayKitApp(prefs)
                }
            }
        }
    }
}

@Composable
fun PlayKitApp(prefs: Prefs) {
    var tab by remember { mutableIntStateOf(0) }
    var openToolId by remember { mutableStateOf<String?>(null) }
    var filterName by remember { mutableStateOf<String?>(null) }
    val favorites = remember { mutableStateListOf<String>().apply { addAll(prefs.getList("favorites")) } }
    val recents = remember { mutableStateListOf<String>().apply { addAll(prefs.getList("recent")) } }

    fun openTool(id: String) {
        openToolId = id
        recents.remove(id)
        recents.add(0, id)
        while (recents.size > 6) recents.removeAt(recents.size - 1)
        prefs.putList("recent", recents.toList())
    }

    fun toggleFav(id: String) {
        if (favorites.contains(id)) favorites.remove(id) else favorites.add(id)
        prefs.putList("favorites", favorites.toList())
    }

    BackHandler(enabled = openToolId != null) { openToolId = null }
    BackHandler(enabled = openToolId == null && tab != 0) { tab = 0 }

    AppBackground {
        val tool = openToolId?.let { id -> AllTools.firstOrNull { it.id == id } }
        if (tool != null) {
            key(tool.id) {
                ToolScaffold(
                    title = tool.title,
                    emoji = tool.emoji,
                    desc = tool.desc,
                    isFav = favorites.contains(tool.id),
                    onFav = { toggleFav(tool.id) },
                    onBack = { openToolId = null }
                ) {
                    tool.content()
                }
            }
        } else {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f)) {
                    when (tab) {
                        0 -> HomeScreen(
                            favorites = favorites.toList(),
                            recents = recents.toList(),
                            onOpen = { openTool(it) },
                            onCategory = { c ->
                                filterName = c.name
                                tab = 1
                            }
                        )
                        1 -> AllToolsScreen(
                            filter = Cats.all.firstOrNull { it.name == filterName },
                            onFilter = { filterName = it?.name },
                            onOpen = { openTool(it) }
                        )
                        else -> SavedScreen(favorites.toList()) { openTool(it) }
                    }
                }
                NavigationBar(containerColor = NavyLight) {
                    NavigationBarItem(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        icon = { Text("🏠", fontSize = 22.sp) },
                        label = { Text("Ana Sayfa", fontSize = 12.sp) }
                    )
                    NavigationBarItem(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        icon = { Text("🧰", fontSize = 22.sp) },
                        label = { Text("Tüm Araçlar", fontSize = 12.sp) }
                    )
                    NavigationBarItem(
                        selected = tab == 2,
                        onClick = { tab = 2 },
                        icon = { Text("⭐", fontSize = 22.sp) },
                        label = { Text("Kaydedilenler", fontSize = 12.sp) }
                    )
                }
            }
        }
    }
}
