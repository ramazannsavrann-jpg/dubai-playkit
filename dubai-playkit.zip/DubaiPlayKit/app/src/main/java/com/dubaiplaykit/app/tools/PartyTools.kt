package com.dubaiplaykit.app.tools

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dubaiplaykit.app.data.LocalPrefs
import com.dubaiplaykit.app.data.rememberPersistentList
import com.dubaiplaykit.app.logic.*
import com.dubaiplaykit.app.ui.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

private val sampleTasks = listOf(
    "Bir şarkının nakaratını söyle",
    "30 saniye boyunca hiç gülmeden bak",
    "Sağındaki kişiye iltifat et",
    "Bir hayvanı taklit et, diğerleri bilsin",
    "10 saniye tek ayak üstünde dur",
    "Bir fıkra anlat",
    "En sevdiğin filmi sadece mimikle anlat",
    "Bir dakika boyunca sadece fısıltıyla konuş",
    "Telefonundaki son fotoğrafı göster ve anlat",
    "Beş farklı meyve say (5 saniyede)"
)

@Composable
fun TaskTool() {
    val tasks = rememberPersistentList("tasks_items", sampleTasks)
    val used = remember { mutableStateListOf<String>() }
    var noRepeat by remember { mutableStateOf(true) }
    var current by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    val c = current
    if (c != null) ResultCard(c, Coral, Color.White)
    ErrorText(message)
    BigButton("GÖREV SEÇ") {
        val pick = Picker.pick(tasks.items.toList(), used.toSet(), noRepeat)
        if (pick == null) {
            message = if (tasks.items.isEmpty()) "Önce görev ekle." else "Bütün görevler çıktı! Sıfırlayabilirsin."
        } else {
            message = null
            current = pick
            used.add(pick)
        }
    }
    SwitchRow("Seçilen görev tekrar seçilmesin", noRepeat) { noRepeat = it }
    SoftButton("Çıkan görevleri sıfırla (${used.size})") { used.clear(); message = null }
    Panel {
        Text("Görevler (ekle / düzenle / sil)", color = Color.White, fontWeight = FontWeight.Bold)
        ListEditor(tasks, "Yeni görev")
    }
}

@Composable
fun HiddenChoiceTool() {
    val prefs = LocalPrefs.current
    val players = rememberPersistentList("hidden_players", listOf("Oyuncu 1", "Oyuncu 2", "Oyuncu 3"))
    val options = rememberPersistentList("hidden_options", listOf("Evet", "Hayır", "Belki"))
    var question by remember { mutableStateOf(prefs.getString("hidden_question", "Sence hangisi doğru?")) }
    var phase by remember { mutableIntStateOf(0) } // 0 ayar, 1 seçim, 2 devir, 3 sonuç
    var current by remember { mutableIntStateOf(0) }
    var names by remember { mutableStateOf<List<String>>(emptyList()) }
    val picks = remember { mutableStateListOf<String>() }
    var error by remember { mutableStateOf<String?>(null) }

    when (phase) {
        0 -> {
            Panel {
                Text("Soru / görev", color = Color.White, fontWeight = FontWeight.Bold)
                AppField(question, { question = it }, "Soru")
            }
            Panel {
                Text("Oyuncular", color = Color.White, fontWeight = FontWeight.Bold)
                ListEditor(players, "Oyuncu adı")
            }
            Panel {
                Text("Seçenekler", color = Color.White, fontWeight = FontWeight.Bold)
                ListEditor(options, "Seçenek")
            }
            ErrorText(error)
            BigButton("OYUNU BAŞLAT") {
                if (players.items.size < 2) {
                    error = "En az 2 oyuncu gerekli."
                } else if (options.items.size < 2) {
                    error = "En az 2 seçenek gerekli."
                } else {
                    error = null
                    prefs.putString("hidden_question", question)
                    names = players.items.toList()
                    picks.clear()
                    current = 0
                    phase = 1
                }
            }
        }
        1 -> {
            Panel {
                Text(names[current], color = Sun, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Text(question, color = Color.White, fontSize = 18.sp)
                Text("Seçimin diğerlerine görünmeyecek.", color = Muted, fontSize = 13.sp)
            }
            options.items.toList().forEach { opt ->
                BigButton(opt, color = NavyLighter) {
                    picks.add(opt)
                    if (current + 1 < names.size) {
                        current += 1
                        phase = 2
                    } else {
                        phase = 3
                    }
                }
            }
        }
        2 -> {
            Panel {
                Text("Seçim gizlendi ✔", color = Good, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Telefonu ${names[current]} oyuncusuna ver.", color = Color.White)
            }
            BigButton("${names[current]} HAZIR") { phase = 1 }
        }
        else -> {
            Panel {
                Text("Sonuçlar", color = Sun, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text(question, color = Muted)
                names.forEachIndexed { i, n ->
                    Row(Modifier.fillMaxWidth()) {
                        Text(n, color = Color.White, modifier = Modifier.weight(1f))
                        Text(picks.getOrNull(i) ?: "-", color = Turquoise, fontWeight = FontWeight.Bold)
                    }
                }
            }
            BigButton("AYNI OYUNCULARLA YENİ TUR") {
                picks.clear()
                current = 0
                phase = 1
            }
            SoftButton("Ayarlara dön", Modifier.fillMaxWidth()) { phase = 0 }
        }
    }
}

@Composable
fun FingersTool() {
    var result by remember { mutableStateOf<String?>(null) }
    var big by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Panel {
        Text("Nasıl oynanır?", color = Color.White, fontWeight = FontWeight.Bold)
        Text(
            "Bir oyuncu TEK, diğeri ÇİFT seçer. İkisi aynı anda 0-5 parmak gösterir. " +
                "Parmak toplamı tek ise TEK seçen, çift ise ÇİFT seçen kazanır.",
            color = Muted, fontSize = 14.sp
        )
    }
    val b = big
    if (b != null) {
        Text(b, color = Sun, fontSize = 56.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
    }
    val r = result
    if (r != null) ResultCard(r, Purple, Color.White)
    BigButton("KİM TEK, KİM ÇİFT?", enabled = !busy) {
        result = if (Random.nextBoolean()) "1. oyuncu TEK\n2. oyuncu ÇİFT" else "1. oyuncu ÇİFT\n2. oyuncu TEK"
        big = null
    }
    BigButton("RASTGELE TEK / ÇİFT", color = Coral, enabled = !busy) {
        result = if (Random.nextBoolean()) "TEK" else "ÇİFT"
        big = null
    }
    BigButton("3-2-1 PARMAK GÖSTER", color = Sun, enabled = !busy) {
        busy = true
        result = null
        scope.launch {
            for (n in listOf("3", "2", "1")) {
                big = n
                delay(800)
            }
            val fingers = Random.nextInt(0, 6)
            big = "GÖSTER!"
            delay(700)
            big = null
            result = "Telefonun parmağı: $fingers\n(" + (if (fingers % 2 == 0) "ÇİFT" else "TEK") + ")"
            busy = false
        }
    }
}
