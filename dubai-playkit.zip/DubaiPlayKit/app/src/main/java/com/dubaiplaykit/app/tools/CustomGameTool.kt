package com.dubaiplaykit.app.tools

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dubaiplaykit.app.data.LocalPrefs
import com.dubaiplaykit.app.logic.Codec
import com.dubaiplaykit.app.logic.CustomGame
import com.dubaiplaykit.app.logic.Picker
import com.dubaiplaykit.app.ui.*

@Composable
fun CustomGameTool() {
    val prefs = LocalPrefs.current
    val games = remember { mutableStateListOf<CustomGame>().apply { addAll(prefs.getGames()) } }
    var mode by remember { mutableIntStateOf(0) } // 0 liste, 1 düzenle, 2 oyna
    var index by remember { mutableIntStateOf(-1) }
    var draftName by remember { mutableStateOf("") }
    val draftItems = remember { mutableStateListOf<String>() }
    var error by remember { mutableStateOf<String?>(null) }
    var deleteIndex by remember { mutableIntStateOf(-1) }

    fun save() = prefs.putGames(games.toList())

    BackHandler(enabled = mode != 0) { mode = 0 }

    when (mode) {
        0 -> {
            BigButton("➕ YENİ OYUN OLUŞTUR") {
                index = -1
                draftName = ""
                draftItems.clear()
                error = null
                mode = 1
            }
            if (games.isEmpty()) {
                Text(
                    "Henüz kendi oyunun yok. İsim, seçenek veya görev listesi oluştur; telefonuna kaydedilir ve istediğin zaman tekrar kullanırsın.",
                    color = Muted, fontSize = 14.sp
                )
            }
            games.toList().forEachIndexed { i, g ->
                Panel {
                    Text(g.name, color = Sun, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    Text("${g.items.size} öğe", color = Muted, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        SoftButton("Oyna", Modifier.weight(1f)) { index = i; mode = 2 }
                        SoftButton("Düzenle", Modifier.weight(1f)) {
                            index = i
                            draftName = g.name
                            draftItems.clear()
                            draftItems.addAll(g.items)
                            error = null
                            mode = 1
                        }
                        SoftButton("Sil", Modifier.weight(1f)) { deleteIndex = i }
                    }
                }
            }
        }
        1 -> {
            Panel {
                Text("Oyunun adı", color = Color.White, fontWeight = FontWeight.Bold)
                AppField(draftName, { draftName = it }, "Örn: Akşam görevleri")
            }
            Panel {
                Text("Öğeler (isim, seçenek veya görev)", color = Color.White, fontWeight = FontWeight.Bold)
                ListEditorCore(
                    items = draftItems,
                    hint = "Yeni öğe",
                    addLabel = "Ekle",
                    onAdd = { draftItems.add(it) },
                    onUpdate = { i, s -> if (i in draftItems.indices) draftItems[i] = s },
                    onRemove = { if (it in draftItems.indices) draftItems.removeAt(it) }
                )
            }
            ErrorText(error)
            BigButton("KAYDET") {
                val name = Codec.clean(draftName)
                if (name.isEmpty()) {
                    error = "Oyuna bir ad ver."
                } else if (draftItems.isEmpty()) {
                    error = "En az 1 öğe ekle."
                } else {
                    val g = CustomGame(name, draftItems.toList())
                    if (index in games.indices) games[index] = g else games.add(g)
                    save()
                    mode = 0
                }
            }
            SoftButton("Vazgeç", Modifier.fillMaxWidth()) { mode = 0 }
        }
        else -> {
            val g = games.getOrNull(index)
            if (g == null) {
                mode = 0
            } else {
                CustomGamePlay(g) { mode = 0 }
            }
        }
    }

    if (deleteIndex in games.indices) {
        ConfirmDialog(
            "Oyun silinsin mi?",
            "\"${games[deleteIndex].name}\" kalıcı olarak silinecek.",
            onConfirm = {
                games.removeAt(deleteIndex)
                save()
                deleteIndex = -1
            },
            onDismiss = { deleteIndex = -1 }
        )
    }
}

@Composable
private fun CustomGamePlay(game: CustomGame, onBack: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var noRepeat by remember { mutableStateOf(true) }
    val used = remember { mutableStateListOf<String>() }
    var current by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    Text(game.name, color = Sun, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
    ChipSelector(listOf(0, 1), tab, { if (it == 0) "Çark" else "Rastgele seç" }) { tab = it }
    if (tab == 0) {
        SpinWheel(game.items, WheelPalette, "ÇARKI ÇEVİR")
    } else {
        val c = current
        if (c != null) ResultCard(c, Coral, Color.White)
        ErrorText(message)
        BigButton("RASTGELE SEÇ") {
            val pick = Picker.pick(game.items, used.toSet(), noRepeat)
            if (pick == null) {
                message = "Bütün öğeler çıktı! Sıfırlayabilirsin."
            } else {
                message = null
                current = pick
                used.add(pick)
            }
        }
        SwitchRow("Seçilen öğe tekrar seçilmesin", noRepeat) { noRepeat = it }
        SoftButton("Çıkanları sıfırla (${used.size})") { used.clear(); message = null }
    }
    SoftButton("← Listeye dön", Modifier.fillMaxWidth(), onClick = onBack)
}
