package com.dubaiplaykit.app.tools

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.SystemClock
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dubaiplaykit.app.data.LocalPrefs
import com.dubaiplaykit.app.logic.Countdown
import com.dubaiplaykit.app.ui.*
import kotlinx.coroutines.delay

/** Süre, gerçek (uyku dahil) geçen zamandan hesaplanır; ekran kilitlense bile tutarlı kalır. */
object HourglassState {
    var totalMs by mutableLongStateOf(30_000L)
    var remainingMs by mutableLongStateOf(30_000L)
    var endAt by mutableLongStateOf(0L)
    var running by mutableStateOf(false)
    var finished by mutableStateOf(false)

    fun setTotal(sec: Int) {
        running = false
        finished = false
        totalMs = sec * 1000L
        remainingMs = totalMs
    }

    fun start() {
        if (remainingMs <= 0L) remainingMs = totalMs
        finished = false
        endAt = SystemClock.elapsedRealtime() + remainingMs
        running = true
    }

    fun pause() {
        remainingMs = Countdown.remaining(endAt, SystemClock.elapsedRealtime())
        running = false
    }

    fun reset() {
        running = false
        finished = false
        remainingMs = totalMs
    }
}

private suspend fun beep() {
    var tg: ToneGenerator? = null
    try {
        tg = ToneGenerator(AudioManager.STREAM_ALARM, 100)
        tg.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1200)
        delay(1500)
    } catch (e: Exception) {
        // ses çalınamazsa görsel uyarı yeterli
    } finally {
        tg?.release()
    }
}

@Composable
fun HourglassTool() {
    val st = HourglassState
    val prefs = LocalPrefs.current
    var sound by remember { mutableStateOf(prefs.getBool("sound_on", true)) }
    var customText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(st.running, st.endAt) {
        while (st.running) {
            val rem = Countdown.remaining(st.endAt, SystemClock.elapsedRealtime())
            st.remainingMs = rem
            if (rem <= 0L) {
                st.running = false
                st.finished = true
                if (prefs.getBool("sound_on", true)) beep()
                break
            }
            delay(50)
        }
    }

    val idle = !st.running && !st.finished && st.remainingMs == st.totalMs
    val paused = !st.running && !st.finished && st.remainingMs < st.totalMs
    val fraction = if (st.totalMs > 0) (st.remainingMs.toFloat() / st.totalMs.toFloat()).coerceIn(0f, 1f) else 0f

    val flash = rememberInfiniteTransition(label = "flash")
    val flashAlpha by flash.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.6f,
        animationSpec = infiniteRepeatable(tween(450), RepeatMode.Reverse),
        label = "flashAlpha"
    )

    if (idle || st.finished) {
        ChipSelector(listOf(15, 30, 45, 60), (st.totalMs / 1000L).toInt(), { "$it sn" }) { st.setTotal(it) }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AppField(customText, { customText = it }, "Özel süre (saniye)", Modifier.weight(1f), numeric = true)
            SoftButton("Ayarla") {
                val n = customText.trim().toIntOrNull()
                if (n == null || n < 1 || n > 3600) {
                    error = "1 ile 3600 saniye arasında bir değer gir."
                } else {
                    error = null
                    st.setTotal(n)
                    customText = ""
                }
            }
        }
        ErrorText(error)
    }

    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(if (st.finished) Bad.copy(alpha = flashAlpha) else NavyLight)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Canvas(Modifier.size(width = 200.dp, height = 250.dp)) {
                val w = this.size.width
                val h = this.size.height
                fun pt(x: Float, y: Float) = Offset(x * w, y * h)
                val frame = Path().apply {
                    moveTo(pt(0.15f, 0.04f).x, pt(0.15f, 0.04f).y)
                    lineTo(pt(0.85f, 0.04f).x, pt(0.85f, 0.04f).y)
                    lineTo(pt(0.52f, 0.5f).x, pt(0.52f, 0.5f).y)
                    lineTo(pt(0.85f, 0.96f).x, pt(0.85f, 0.96f).y)
                    lineTo(pt(0.15f, 0.96f).x, pt(0.15f, 0.96f).y)
                    lineTo(pt(0.48f, 0.5f).x, pt(0.48f, 0.5f).y)
                    close()
                }
                // üst bölmedeki kum
                if (fraction > 0f) {
                    val ys = 0.04f + 0.46f * (1f - fraction)
                    val half = 0.35f * (0.5f - ys) / 0.46f + 0.02f
                    val top = Path().apply {
                        moveTo((0.5f - half) * w, ys * h)
                        lineTo((0.5f + half) * w, ys * h)
                        lineTo(0.5f * w, 0.5f * h)
                        close()
                    }
                    drawPath(top, Sun)
                }
                // alt bölmedeki kum
                val g = 1f - fraction
                if (g > 0f) {
                    val yb = 0.96f - 0.46f * g
                    val half = 0.35f * (yb - 0.5f) / 0.46f + 0.02f
                    val bottom = Path().apply {
                        moveTo(0.15f * w, 0.96f * h)
                        lineTo(0.85f * w, 0.96f * h)
                        lineTo((0.5f + half) * w, yb * h)
                        lineTo((0.5f - half) * w, yb * h)
                        close()
                    }
                    drawPath(bottom, Sun)
                }
                if (st.running && fraction > 0f) {
                    val yb = 0.96f - 0.46f * (1f - fraction)
                    drawLine(Sun, Offset(0.5f * w, 0.5f * h), Offset(0.5f * w, yb * h), strokeWidth = 4f)
                }
                drawPath(frame, Color.White, style = Stroke(width = 6f))
            }
            Text(
                if (st.finished) "SÜRE DOLDU!" else Countdown.format(st.remainingMs),
                color = Color.White,
                fontSize = if (st.finished) 30.sp else 48.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )
        }
    }

    if (st.running) {
        BigButton("DURAKLAT", color = Coral) { st.pause() }
    } else if (paused) {
        BigButton("DEVAM ET") { st.start() }
    } else if (st.finished) {
        BigButton("TEKRAR BAŞLAT") { st.start() }
    } else {
        BigButton("BAŞLAT") { st.start() }
    }
    if (!idle) SoftButton("Sıfırla", Modifier.fillMaxWidth()) { st.reset() }
    SwitchRow("Süre bitince ses çal", sound) {
        sound = it
        prefs.putBool("sound_on", it)
    }
    Text(
        "Sayaç gerçek zamana göre çalışır; ekranı kilitleyip geri döndüğünde süre doğru kalır.",
        color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center
    )
}
