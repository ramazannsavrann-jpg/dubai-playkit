package com.dubaiplaykit.app.tools

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dubaiplaykit.app.data.PersistentStringList
import com.dubaiplaykit.app.data.rememberPersistentList
import com.dubaiplaykit.app.logic.Codec
import com.dubaiplaykit.app.logic.Pairs
import com.dubaiplaykit.app.logic.Teams
import com.dubaiplaykit.app.ui.*

private const val SEP = '\u0004'
private val defaultPlayers = listOf("Oyuncu 1", "Oyuncu 2", "Oyuncu 3", "Oyuncu 4")

@Composable
fun ScoreTool() {
    val entries = rememberPersistentList("score_entries", listOf("Oyuncu 1${SEP}0", "Oyuncu 2${SEP}0"))
    var newName by remember { mutableStateOf("") }
    var renameIndex by remember { mutableIntStateOf(-1) }
    var confirmReset by remember { mutableStateOf(false) }

    fun nameOf(e: String): String = e.substringBefore(SEP)
    fun scoreOf(e: String): Int = e.substringAfter(SEP, "0").toIntOrNull() ?: 0

    entries.items.toList().forEachIndexed { i, e ->
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(NavyLight).padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                nameOf(e),
                modifier = Modifier.weight(1f).clickable { renameIndex = i },
                color = Color.White,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            RoundBtn("−", 42.dp, Coral) { entries.update(i, nameOf(e) + SEP + (scoreOf(e) - 1)) }
            Text(scoreOf(e).toString(), color = Sun, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.widthIn(min = 52.dp), textAlign = TextAlign.Center)
            RoundBtn("+", 42.dp, Good) { entries.update(i, nameOf(e) + SEP + (scoreOf(e) + 1)) }
            if (entries.items.size > 2) {
                Text("✕", color = Muted, fontSize = 20.sp, modifier = Modifier.clickable { entries.removeAt(i) }.padding(6.dp))
            }
        }
    }
    Text("İsmi değiştirmek için ismin üzerine dokun.", color = Muted, fontSize = 13.sp)
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        AppField(newName, { newName = it }, "Yeni oyuncu", Modifier.weight(1f))
        SoftButton("Ekle") {
            val t = Codec.clean(newName)
            if (t.isNotEmpty()) {
                entries.add(t + SEP + "0")
                newName = ""
            }
        }
    }
    SoftButton("Puanları sıfırla", Modifier.fillMaxWidth()) { confirmReset = true }

    if (confirmReset) {
        ConfirmDialog(
            "Puanlar sıfırlansın mı?",
            "Bütün oyuncuların puanı 0 olacak.",
            onConfirm = {
                entries.items.toList().forEachIndexed { i, e -> entries.update(i, nameOf(e) + SEP + "0") }
                confirmReset = false
            },
            onDismiss = { confirmReset = false }
        )
    }
    if (renameIndex in entries.items.indices) {
        val e = entries.items[renameIndex]
        RenameDialog(
            initial = nameOf(e),
            onSave = { n ->
                entries.update(renameIndex, n + SEP + scoreOf(e))
                renameIndex = -1
            },
            onDismiss = { renameIndex = -1 }
        )
    }
}

@Composable
private fun PlayersPanel(players: PersistentStringList) {
    Panel {
        Text("Oyuncular", color = Color.White, fontWeight = FontWeight.Bold)
        ListEditor(players, "Oyuncu adı")
    }
}

@Composable
fun TeamsTool() {
    val players = rememberPersistentList("players", defaultPlayers)
    var byCount by remember { mutableStateOf(true) }
    var value by remember { mutableIntStateOf(2) }
    var teams by remember { mutableStateOf<List<List<String>>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }

    PlayersPanel(players)
    Panel {
        ChipSelector(listOf(true, false), byCount, { if (it) "Takım sayısı" else "Takım başına oyuncu" }) { byCount = it }
        Stepper(value, 1, 20) { value = it }
    }
    ErrorText(error)
    BigButton("TAKIMLARI OLUŞTUR") {
        val list = players.items.toList()
        if (list.size < 2) {
            error = "En az 2 oyuncu ekle."
            teams = emptyList()
        } else {
            val count = if (byCount) value else Teams.teamCountForSize(list.size, value)
            if (count > list.size) {
                error = "Takım sayısı oyuncu sayısından fazla olamaz."
                teams = emptyList()
            } else {
                error = null
                teams = Teams.split(list, count)
            }
        }
    }
    teams.forEachIndexed { i, t ->
        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = WheelPalette[i % WheelPalette.size].copy(alpha = 0.28f))
        ) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Takım ${i + 1} (${t.size} kişi)", color = Sun, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                t.forEach { Text("• $it", color = Color.White, fontSize = 16.sp) }
            }
        }
    }
}

@Composable
fun OrderTool() {
    val players = rememberPersistentList("players", defaultPlayers)
    var order by remember { mutableStateOf<List<String>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    PlayersPanel(players)
    ErrorText(error)
    BigButton(if (order.isEmpty()) "SIRALA" else "YENİDEN SIRALA") {
        val list = players.items.toList()
        if (list.size < 2) {
            error = "En az 2 oyuncu ekle."
            order = emptyList()
        } else {
            error = null
            order = list.shuffled()
        }
    }
    if (order.isNotEmpty()) {
        Panel {
            Text("Oyun sırası", color = Sun, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            order.forEachIndexed { i, n ->
                Text("${i + 1}. $n", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun PairsTool() {
    val players = rememberPersistentList("players", defaultPlayers)
    var pairs by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var leftOver by remember { mutableStateOf<String?>(null) }
    var done by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    PlayersPanel(players)
    Text("Oyuncu sayısı tekse son kalan oyuncu bu turda dinlenir.", color = Muted, fontSize = 13.sp)
    ErrorText(error)
    BigButton(if (done) "YENİDEN EŞLEŞTİR" else "EŞLEŞTİR") {
        val list = players.items.toList()
        if (list.size < 2) {
            error = "En az 2 oyuncu ekle."
            pairs = emptyList()
            leftOver = null
            done = false
        } else {
            error = null
            val r = Pairs.make(list)
            pairs = r.pairs
            leftOver = r.leftOver
            done = true
        }
    }
    if (done) {
        Panel {
            Text("Eşleşmeler", color = Sun, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            pairs.forEach { p ->
                Text("${p.first}  ⇄  ${p.second}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            val l = leftOver
            if (l != null) Text("Dinlenen: $l", color = Coral, fontWeight = FontWeight.Bold)
        }
    }
}
