package com.dubaiplaykit.app.tools

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.dubaiplaykit.app.ui.Coral
import com.dubaiplaykit.app.ui.Purple
import com.dubaiplaykit.app.ui.Sun
import com.dubaiplaykit.app.ui.Turquoise

class Category(val name: String, val emoji: String, val color: Color, val blurb: String)

object Cats {
    val chance = Category("Şans ve seçim", "🎲", Turquoise, "Çark, yazı tura, şişe")
    val party = Category("Parti oyunları", "🎉", Coral, "Görev, gizli seçim, parmak")
    val players = Category("Oyuncular ve takımlar", "👥", Purple, "Puan, takım, sıra, eşleşme")
    val board = Category("Masa oyunları", "♟️", Sun, "Zar, kart, domino, XOX")
    val timers = Category("Zamanlayıcılar", "⏳", Color(0xFF4FC3F7), "Kum saati geri sayım")
    val custom = Category("Kendi oyununu oluştur", "🛠️", Color(0xFF9CCC65), "Kendi listelerin")
    val all: List<Category> = listOf(chance, party, players, board, timers, custom)
}

class ToolDef(
    val id: String,
    val title: String,
    val emoji: String,
    val category: Category,
    val desc: String,
    val content: @Composable () -> Unit
)

/** 22 aracın tamamı burada kayıtlıdır. */
val AllTools: List<ToolDef> = listOf(
    // A. Şans ve rastgele seçim (7)
    ToolDef("bottle", "Şişe Çevirme", "🍾", Cats.chance, "Şişeyi çevir, ağzı kime dönerse o seçilir.") { BottleTool() },
    ToolDef("coin", "Yazı Tura", "🪙", Cats.chance, "Parayı at; YAZI mı TURA mı?") { CoinTool() },
    ToolDef("colorwheel", "Renk Çarkı", "🎨", Cats.chance, "Çarkı çevir, rastgele bir renk seç.") { ColorWheelTool() },
    ToolDef("namewheel", "İsim ve Seçenek Çarkı", "🎡", Cats.chance, "Kendi isimlerinle çark oluştur ve çevir.") { NameWheelTool() },
    ToolDef("randnum", "Rastgele Sayı", "🔢", Cats.chance, "İstediğin aralıkta rastgele sayı üret.") { RandomNumberTool() },
    ToolDef("yesno", "Evet / Hayır", "❓", Cats.chance, "Tek dokunuşla EVET veya HAYIR.") { YesNoTool() },
    ToolDef("letter", "İsim-Şehir Harf Seçici", "🔤", Cats.chance, "Türk alfabesinden rastgele harf seç.") { LetterTool() },
    // B. Zar ve masa oyunları (5) + parti (4)
    ToolDef("dice", "Zar Atma", "🎲", Cats.board, "1-20 arası standart zar at, toplamı gör.") { DiceTool() },
    ToolDef("polydice", "Çok Yüzlü Zarlar", "🔷", Cats.board, "D4, D6, D8, D10, D12 ve D20 zarları.") { PolyDiceTool() },
    ToolDef("cards", "İskambil Destesi", "🃏", Cats.board, "52 kartlık deste: kart çek, tekrarını önle.") { CardsTool() },
    ToolDef("domino", "Domino", "🁣", Cats.board, "Çift altılı domino seti, taş çek.") { DominoTool() },
    ToolDef("rps", "Taş-Kâğıt-Makas", "✂️", Cats.party, "Tek veya iki telefonla iki oyunculu oyun.") { RpsTool() },
    ToolDef("xox", "XOX", "❌", Cats.board, "İki kişilik klasik XOX.") { XoxTool() },
    ToolDef("hidden", "Gizli Seçim Oyunu", "🙈", Cats.party, "Herkes gizlice seçer, sonunda birlikte açılır.") { HiddenChoiceTool() },
    ToolDef("fingers", "Tek-Çift / Parmak Oyunu", "🖐️", Cats.party, "Tek-çift ve parmak oyunu yardımcısı.") { FingersTool() },
    // C. Oyuncu ve puan araçları (5)
    ToolDef("score", "Puan Sayacı", "🏆", Cats.players, "Oyuncuların puanını tut.") { ScoreTool() },
    ToolDef("teams", "Takım Oluşturucu", "👥", Cats.players, "Oyuncuları dengeli takımlara ayır.") { TeamsTool() },
    ToolDef("order", "Oyuncu Sıralayıcı", "🔀", Cats.players, "Oyuncuları rastgele sıraya diz.") { OrderTool() },
    ToolDef("pairs", "Rastgele Eşleştirme", "🤝", Cats.players, "Oyuncuları ikili eşleştir.") { PairsTool() },
    ToolDef("tasks", "Rastgele Görev", "📝", Cats.party, "Görev seç; kendi görevlerini ekle.") { TaskTool() },
    // D. Zamanlayıcı ve kişiselleştirme (2)
    ToolDef("hourglass", "Kum Saati Geri Sayım", "⏳", Cats.timers, "Süreyi belirle, kum akarken geri say.") { HourglassTool() },
    ToolDef("custom", "Kendi Oyununu Oluştur", "🛠️", Cats.custom, "Kendi isim, seçenek ve görev listelerini kaydet.") { CustomGameTool() }
)
