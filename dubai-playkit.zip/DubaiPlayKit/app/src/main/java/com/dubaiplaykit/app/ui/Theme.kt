package com.dubaiplaykit.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF0B1B3A)
val NavyLight = Color(0xFF14284F)
val NavyLighter = Color(0xFF1E3A70)
val Turquoise = Color(0xFF19C3C0)
val Coral = Color(0xFFFF6B4A)
val Sun = Color(0xFFFFC93C)
val Purple = Color(0xFF8B5CF6)
val Good = Color(0xFF2EBD85)
val Bad = Color(0xFFFF5470)
val Muted = Color(0xFFB6C2D9)

val WheelPalette: List<Color> = listOf(
    Turquoise, Coral, Sun, Purple,
    Color(0xFF4FC3F7), Color(0xFFEF5DA8), Color(0xFF7CB342), Color(0xFFFF9800)
)

@Composable
fun PlayKitTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Turquoise,
            onPrimary = Navy,
            secondary = Coral,
            tertiary = Sun,
            background = Navy,
            surface = NavyLight,
            onBackground = Color.White,
            onSurface = Color.White,
            surfaceVariant = NavyLighter,
            onSurfaceVariant = Muted,
            error = Bad
        ),
        content = content
    )
}
