package com.dubaiplaykit.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dubaiplaykit.app.data.PersistentStringList
import com.dubaiplaykit.app.logic.Codec
import com.dubaiplaykit.app.logic.WheelMath
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Navy, Color(0xFF111F47), Color(0xFF1B1747)))),
        content = content
    )
}

@Composable
fun ToolScaffold(
    title: String,
    emoji: String,
    desc: String,
    isFav: Boolean,
    onFav: () -> Unit,
    onBack: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("←", fontSize = 28.sp, color = Color.White) }
            Text(
                "$emoji $title",
                modifier = Modifier.weight(1f),
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            TextButton(onClick = onFav) { Text(if (isFav) "⭐" else "☆", fontSize = 26.sp, color = Sun) }
        }
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(desc, color = Muted, fontSize = 14.sp, textAlign = TextAlign.Center)
            content()
        }
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = NavyLight)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable
fun BigButton(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Turquoise,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.fillMaxWidth().heightIn(min = 56.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Navy)
    ) {
        Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}

@Composable
fun SoftButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.heightIn(min = 48.dp),
        shape = RoundedCornerShape(14.dp)
    ) {
        Text(text, fontSize = 15.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun RoundBtn(label: String, size: Dp = 48.dp, color: Color = Turquoise, onClick: () -> Unit) {
    Box(
        Modifier.size(size).clip(CircleShape).background(color).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Navy, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Stepper(value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        RoundBtn("−") { if (value > min) onChange(value - 1) }
        Text(value.toString(), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        RoundBtn("+") { if (value < max) onChange(value + 1) }
    }
}

@Composable
fun <T> ChipSelector(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { o ->
            val sel = o == selected
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (sel) Turquoise else NavyLighter)
                    .clickable { onSelect(o) }
                    .padding(horizontal = 18.dp, vertical = 12.dp)
            ) {
                Text(label(o), color = if (sel) Navy else Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f), fontSize = 15.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun ResultCard(text: String, color: Color = Turquoise, textColor: Color = Navy) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(color).padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = textColor, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
    }
}

@Composable
fun AppField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    numeric: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = modifier,
        keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Number else KeyboardType.Text),
        shape = RoundedCornerShape(14.dp)
    )
}

@Composable
fun ErrorText(text: String?) {
    if (text != null) Text(text, color = Bad, fontSize = 14.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun ConfirmDialog(title: String, text: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Evet") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } }
    )
}

@Composable
fun RenameDialog(initial: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("İsmi değiştir") },
        text = { AppField(text, { text = it }, "İsim") },
        confirmButton = {
            TextButton(onClick = {
                val t = Codec.clean(text)
                if (t.isNotEmpty()) onSave(t)
            }) { Text("Kaydet") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } }
    )
}

@Composable
fun ListEditor(list: PersistentStringList, hint: String, addLabel: String = "Ekle") {
    ListEditorCore(
        items = list.items,
        hint = hint,
        addLabel = addLabel,
        onAdd = { list.add(it) },
        onUpdate = { i, s -> list.update(i, s) },
        onRemove = { list.removeAt(it) }
    )
}

@Composable
fun ListEditorCore(
    items: List<String>,
    hint: String,
    addLabel: String,
    onAdd: (String) -> Unit,
    onUpdate: (Int, String) -> Unit,
    onRemove: (Int) -> Unit
) {
    var input by remember { mutableStateOf("") }
    var editIndex by remember { mutableIntStateOf(-1) }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AppField(input, { input = it }, hint, Modifier.weight(1f))
            Button(
                onClick = {
                    val t = Codec.clean(input)
                    if (t.isNotEmpty()) {
                        if (editIndex in items.indices) onUpdate(editIndex, t) else onAdd(t)
                        input = ""
                        editIndex = -1
                    }
                },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Turquoise, contentColor = Navy)
            ) { Text(if (editIndex >= 0) "Kaydet" else addLabel) }
        }
        items.forEachIndexed { i, s ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(NavyLighter).padding(start = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(s, Modifier.weight(1f), color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
                TextButton(onClick = { editIndex = i; input = s }) { Text("✏️") }
                TextButton(onClick = {
                    onRemove(i)
                    editIndex = -1
                    input = ""
                }) { Text("🗑️") }
            }
        }
    }
}

@Composable
fun PipFace(count: Int, dieSize: Dp, bg: Color = Color.White, pip: Color = Navy) {
    val cells: List<Int> = when (count) {
        1 -> listOf(4)
        2 -> listOf(0, 8)
        3 -> listOf(0, 4, 8)
        4 -> listOf(0, 2, 6, 8)
        5 -> listOf(0, 2, 4, 6, 8)
        6 -> listOf(0, 2, 3, 5, 6, 8)
        else -> emptyList()
    }
    Canvas(Modifier.size(dieSize)) {
        val w = this.size.width
        drawRoundRect(bg, Offset.Zero, Size(w, w), CornerRadius(w * 0.18f, w * 0.18f))
        for (c in cells) {
            val x = w * (0.22f + 0.28f * (c % 3))
            val y = w * (0.22f + 0.28f * (c / 3))
            drawCircle(pip, w * 0.085f, Offset(x, y))
        }
    }
}

private fun polygonPoints(sides: Int): List<Pair<Float, Float>> = when (sides) {
    4 -> listOf(0.5f to 0.08f, 0.95f to 0.9f, 0.05f to 0.9f)
    8 -> listOf(0.5f to 0.02f, 0.96f to 0.5f, 0.5f to 0.98f, 0.04f to 0.5f)
    10 -> listOf(0.5f to 0.02f, 0.95f to 0.38f, 0.5f to 0.98f, 0.05f to 0.38f)
    12 -> regularPolygon(5)
    20 -> regularPolygon(6)
    else -> listOf(0.06f to 0.06f, 0.94f to 0.06f, 0.94f to 0.94f, 0.06f to 0.94f)
}

private fun regularPolygon(n: Int): List<Pair<Float, Float>> {
    val pts = ArrayList<Pair<Float, Float>>()
    for (i in 0 until n) {
        val a = Math.toRadians(-90.0 + 360.0 / n * i)
        pts.add((0.5 + 0.47 * cos(a)).toFloat() to (0.52 + 0.47 * sin(a)).toFloat())
    }
    return pts
}

@Composable
fun PolyDie(sides: Int, value: Int, dieSize: Dp, color: Color = Turquoise) {
    Box(Modifier.size(dieSize), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height
            val path = Path()
            polygonPoints(sides).forEachIndexed { i, p ->
                if (i == 0) path.moveTo(p.first * w, p.second * h) else path.lineTo(p.first * w, p.second * h)
            }
            path.close()
            drawPath(path, color)
        }
        Text(value.toString(), color = Navy, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
    }
}

/** Zarları 4'erli satırlar halinde gösterir. */
@Composable
fun DiceGrid(values: List<Int>, sides: Int) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        values.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { v ->
                    if (sides == 6) PipFace(v, 68.dp) else PolyDie(sides, v, 68.dp)
                }
            }
        }
    }
}

@Composable
fun Wheel(labels: List<String>, colors: List<Color>, rotation: Float, modifier: Modifier = Modifier) {
    val paint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.WHITE
            textAlign = android.graphics.Paint.Align.CENTER
            isFakeBoldText = true
            setShadowLayer(4f, 0f, 0f, android.graphics.Color.BLACK)
        }
    }
    Box(modifier.aspectRatio(1f)) {
        Canvas(Modifier.fillMaxSize().padding(14.dp)) {
            val n = labels.size.coerceAtLeast(1)
            val sweep = 360f / n
            val w = this.size.width
            val h = this.size.height
            val d = minOf(w, h)
            val center = Offset(w / 2f, h / 2f)
            val topLeft = Offset((w - d) / 2f, (h - d) / 2f)
            rotate(rotation, center) {
                for (i in 0 until n) {
                    drawArc(
                        color = colors[i % colors.size],
                        startAngle = i * sweep,
                        sweepAngle = sweep,
                        useCenter = true,
                        topLeft = topLeft,
                        size = Size(d, d)
                    )
                }
                paint.textSize = d * (if (n > 12) 0.045f else 0.065f)
                val nc = drawContext.canvas.nativeCanvas
                for (i in 0 until labels.size) {
                    val text = if (labels[i].length > 12) labels[i].take(11) + "…" else labels[i]
                    nc.save()
                    nc.rotate(i * sweep + sweep / 2f, center.x, center.y)
                    nc.drawText(text, center.x + d * 0.30f, center.y + paint.textSize / 3f, paint)
                    nc.restore()
                }
            }
        }
        Text(
            "▼",
            color = Color.White,
            fontSize = 34.sp,
            modifier = Modifier.align(Alignment.TopCenter).offset(y = (-4).dp)
        )
    }
}

@Composable
fun SpinWheel(
    labels: List<String>,
    colors: List<Color>,
    buttonText: String = "ÇEVİR",
    onPicked: (Int) -> Unit = {}
) {
    val rotation = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var spinning by remember { mutableStateOf(false) }
    var picked by remember(labels) { mutableStateOf<Int?>(null) }
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Wheel(labels, colors, rotation.value, Modifier.fillMaxWidth(0.92f))
        val p = picked
        if (p != null && p in labels.indices) {
            ResultCard(labels[p], colors[p % colors.size])
        }
        BigButton(buttonText, enabled = !spinning && labels.size >= 2) {
            val idx = Random.nextInt(labels.size)
            picked = null
            spinning = true
            scope.launch {
                val target = WheelMath.targetRotation(rotation.value, idx, labels.size)
                rotation.animateTo(target, tween(3600, easing = FastOutSlowInEasing))
                rotation.snapTo(rotation.value % 360f)
                picked = idx
                spinning = false
                onPicked(idx)
            }
        }
        if (labels.size < 2) Text("Çarkı çevirmek için en az 2 seçenek ekle.", color = Muted, fontSize = 14.sp)
    }
}
