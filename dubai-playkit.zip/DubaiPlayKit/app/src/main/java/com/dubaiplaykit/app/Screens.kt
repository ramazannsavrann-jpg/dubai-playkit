package com.dubaiplaykit.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dubaiplaykit.app.data.LocalPrefs
import com.dubaiplaykit.app.tools.AllTools
import com.dubaiplaykit.app.tools.Category
import com.dubaiplaykit.app.tools.Cats
import com.dubaiplaykit.app.tools.ToolDef
import com.dubaiplaykit.app.ui.AppField
import com.dubaiplaykit.app.ui.ChipSelector
import com.dubaiplaykit.app.ui.Muted
import com.dubaiplaykit.app.ui.Navy
import com.dubaiplaykit.app.ui.NavyLight
import com.dubaiplaykit.app.ui.NavyLighter
import com.dubaiplaykit.app.ui.Sun
import com.dubaiplaykit.app.ui.Turquoise
import java.util.Locale

private val trLocale: Locale = Locale.forLanguageTag("tr-TR")

fun searchTools(query: String): List<ToolDef> {
    val q = query.trim().lowercase(trLocale)
    if (q.isEmpty()) return AllTools
    return AllTools.filter {
        it.title.lowercase(trLocale).contains(q) ||
            it.desc.lowercase(trLocale).contains(q) ||
            it.category.name.lowercase(trLocale).contains(q)
    }
}

@Composable
fun ToolRow(tool: ToolDef, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(NavyLight)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            Modifier.size(48.dp).clip(CircleShape).background(tool.category.color.copy(alpha = 0.25f)),
            contentAlignment = Alignment.Center
        ) { Text(tool.emoji, fontSize = 24.sp) }
        Column(Modifier.weight(1f)) {
            Text(tool.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(tool.desc, color = Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Text("›", color = Muted, fontSize = 26.sp)
    }
}

@Composable
private fun CategoryCard(cat: Category, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .height(140.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(cat.color, cat.color.copy(alpha = 0.6f))))
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(cat.emoji, fontSize = 30.sp)
        Text(cat.name, color = Navy, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, lineHeight = 18.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(cat.blurb, color = Navy, fontSize = 12.sp, lineHeight = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun HomeScreen(
    favorites: List<String>,
    recents: List<String>,
    onOpen: (String) -> Unit,
    onCategory: (Category) -> Unit
) {
    val prefs = LocalPrefs.current
    var query by remember { mutableStateOf("") }
    val games = remember { prefs.getGames() }
    val side = Modifier.padding(horizontal = 16.dp)
    // Her ekranda yaklaşık 3,4 kart görünür: sağdaki kesik kart kaydırılabildiğini gösterir.
    val screenW = LocalConfiguration.current.screenWidthDp
    val cardW = ((screenW - 16 - 30) / 3.4f).coerceIn(88f, 124f)
    val quickFont = if (cardW < 90f) 11.sp else 12.sp

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            side.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                Modifier
                    .size(88.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Navy)
                    .border(2.dp, NavyLighter, RoundedCornerShape(22.dp)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(R.drawable.logo_emblem),
                    contentDescription = "DUBAI PlayKit logosu",
                    modifier = Modifier.size(68.dp)
                )
            }
            Column {
                Text("DUBAI", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 4.sp)
                Text("PlayKit", color = Turquoise, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Your Pocket Game Toolkit", color = Muted, fontSize = 13.sp)
            }
        }
        AppField(query, { query = it }, "🔍 Araç ara", side.fillMaxWidth())

        if (query.isNotBlank()) {
            val results = searchTools(query)
            Column(side.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (results.isEmpty()) Text("Sonuç bulunamadı.", color = Muted)
                results.forEach { t -> ToolRow(t) { onOpen(t.id) } }
            }
        } else {
            val defaults = listOf("coin", "dice", "namewheel", "hourglass")
            val ids = (favorites + recents).distinct().ifEmpty { defaults }
            val quick = ids.mapNotNull { id -> AllTools.firstOrNull { it.id == id } }.take(8)
            Text("Sık kullanılanlar", modifier = side, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                quick.forEach { t ->
                    Column(
                        Modifier
                            .size(width = cardW.dp, height = 112.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(NavyLight)
                            .clickable { onOpen(t.id) }
                            .padding(horizontal = 6.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(t.emoji, fontSize = 30.sp, maxLines = 1)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            t.short,
                            color = Color.White,
                            fontSize = quickFont,
                            lineHeight = 15.sp,
                            textAlign = TextAlign.Center,
                            minLines = 2,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            Text("Kategoriler", modifier = side, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Cats.all.chunked(2).forEach { rowCats ->
                Row(side.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    rowCats.forEach { c -> CategoryCard(c, Modifier.weight(1f)) { onCategory(c) } }
                }
            }
            if (games.isNotEmpty()) {
                Text("Kendi oyunlarım", modifier = side, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    games.forEach { g ->
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(50))
                                .background(NavyLighter)
                                .clickable { onOpen("custom") }
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) { Text("🛠️ ${g.name}", color = Color.White, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
    }
}

@Composable
fun AllToolsScreen(filter: Category?, onFilter: (Category?) -> Unit, onOpen: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Tüm Araçlar", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
        AppField(query, { query = it }, "🔍 Araç ara", Modifier.fillMaxWidth())
        ChipSelector(listOf<Category?>(null) + Cats.all, filter, { it?.name ?: "Hepsi" }) { onFilter(it) }
        val found = searchTools(query)
        Cats.all.forEach { cat ->
            if (filter == null || filter == cat) {
                val inCat = found.filter { it.category == cat }
                if (inCat.isNotEmpty()) {
                    Text("${cat.emoji} ${cat.name}", color = Sun, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    inCat.forEach { t -> ToolRow(t) { onOpen(t.id) } }
                }
            }
        }
    }
}

@Composable
fun SavedScreen(favorites: List<String>, onOpen: (String) -> Unit) {
    val prefs = LocalPrefs.current
    val games = remember { prefs.getGames() }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Kaydedilenler", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
        Text("Favori araçlar", color = Sun, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        val favTools = favorites.mapNotNull { id -> AllTools.firstOrNull { it.id == id } }
        if (favTools.isEmpty()) {
            Text("Bir aracın sağ üstündeki ☆ simgesine dokunarak favorilerine ekleyebilirsin.", color = Muted, fontSize = 14.sp)
        }
        favTools.forEach { t -> ToolRow(t) { onOpen(t.id) } }
        Text("Özel oyun listelerim", color = Sun, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        if (games.isEmpty()) {
            Text("Henüz kendi oyununu oluşturmadın.", color = Muted, fontSize = 14.sp)
        }
        games.forEach { g ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(NavyLight)
                    .clickable { onOpen("custom") }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(g.name, color = Color.White, fontWeight = FontWeight.Bold)
                    Text("${g.items.size} öğe", color = Muted, fontSize = 12.sp)
                }
                Text("›", color = Muted, fontSize = 26.sp)
            }
        }
    }
}
