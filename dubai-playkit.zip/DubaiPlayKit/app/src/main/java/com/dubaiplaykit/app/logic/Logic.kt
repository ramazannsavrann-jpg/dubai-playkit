package com.dubaiplaykit.app.logic

import kotlin.math.ceil
import kotlin.random.Random

object Dice {
    const val MAX_COUNT = 20
    val polySides: List<Int> = listOf(4, 6, 8, 10, 12, 20)

    fun roll(sides: Int, rnd: Random = Random.Default): Int {
        require(sides >= 2) { "Zar en az 2 yüzlü olmalı" }
        return rnd.nextInt(1, sides + 1)
    }

    fun rollMany(count: Int, sides: Int, rnd: Random = Random.Default): List<Int> {
        require(count in 1..MAX_COUNT) { "Zar sayısı 1 ile 20 arasında olmalı" }
        return List(count) { roll(sides, rnd) }
    }
}

data class DiceLayoutPlan(val perRow: Int, val sizeDp: Float)

object DiceLayout {
    /** Zarların satır başına sayısını ve boyutunu belirler; hepsi her zaman genişliğe sığar. */
    fun plan(count: Int, availableDp: Float, gapDp: Float = 14f): DiceLayoutPlan {
        val n = count.coerceAtLeast(1)
        val perRow = when {
            n == 1 -> 1
            n == 2 -> 2
            n == 3 -> 3
            n == 4 -> 2
            n <= 6 -> 3
            n <= 12 -> 4
            else -> 5
        }
        val cap = when (perRow) {
            1 -> 180f
            2 -> 150f
            3 -> 110f
            else -> 90f
        }
        val fit = (availableDp - gapDp * (perRow - 1)) / perRow
        return DiceLayoutPlan(perRow, minOf(cap, fit))
    }
}

enum class CoinSide(val label: String) { YAZI("YAZI"), TURA("TURA") }

object Coin {
    fun flip(rnd: Random = Random.Default): CoinSide =
        if (rnd.nextBoolean()) CoinSide.YAZI else CoinSide.TURA
}

data class RangeParse(val min: Int, val max: Int, val error: String?)

object RandomRange {
    const val LIMIT = 1_000_000_000

    fun parse(minText: String, maxText: String): RangeParse {
        val a = minText.trim().toIntOrNull()
        val b = maxText.trim().toIntOrNull()
        if (a == null || b == null) return RangeParse(0, 0, "Lütfen iki alana da tam sayı gir.")
        if (a !in -LIMIT..LIMIT || b !in -LIMIT..LIMIT) {
            return RangeParse(a, b, "Sayılar -1 milyar ile 1 milyar arasında olmalı.")
        }
        if (a > b) return RangeParse(a, b, "Başlangıç değeri bitişten büyük olamaz.")
        return RangeParse(a, b, null)
    }

    fun pick(min: Int, max: Int, rnd: Random = Random.Default): Int = rnd.nextInt(min, max + 1)
}

/** Çekilen öğeyi torbadan çıkaran (veya çıkarmayan) rastgele seçici. */
class ShuffleBag<T>(items: List<T>, private val rnd: Random = Random.Default) {
    private val all: List<T> = items.toList()
    private val remaining: MutableList<T> = all.toMutableList()

    val remainingCount: Int get() = remaining.size
    val totalCount: Int get() = all.size

    fun draw(removeDrawn: Boolean = true): T? {
        if (all.isEmpty()) return null
        if (!removeDrawn) return all[rnd.nextInt(all.size)]
        if (remaining.isEmpty()) return null
        return remaining.removeAt(rnd.nextInt(remaining.size))
    }

    fun reset() {
        remaining.clear()
        remaining.addAll(all)
    }
}

data class Card(val rank: Int, val suit: Int) {
    val rankLabel: String
        get() = when (rank) {
            1 -> "A"
            11 -> "J"
            12 -> "Q"
            13 -> "K"
            else -> rank.toString()
        }
    val suitSymbol: String get() = listOf("♠", "♥", "♦", "♣")[suit]
    val isRed: Boolean get() = suit == 1 || suit == 2
    val label: String get() = rankLabel + suitSymbol
}

object Deck {
    fun standard(): List<Card> {
        val cards = ArrayList<Card>()
        for (s in 0..3) for (r in 1..13) cards.add(Card(r, s))
        return cards
    }
}

data class Tile(val a: Int, val b: Int)

object Dominoes {
    fun doubleSix(): List<Tile> {
        val tiles = ArrayList<Tile>()
        for (a in 0..6) for (b in a..6) tiles.add(Tile(a, b))
        return tiles
    }
}

object TurkishAlphabet {
    const val LETTERS = "ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZ"
    val list: List<String> get() = LETTERS.map { it.toString() }
}

object TicTacToe {
    val lines: List<List<Int>> = listOf(
        listOf(0, 1, 2), listOf(3, 4, 5), listOf(6, 7, 8),
        listOf(0, 3, 6), listOf(1, 4, 7), listOf(2, 5, 8),
        listOf(0, 4, 8), listOf(2, 4, 6)
    )

    fun winningLine(board: List<Char>): List<Int>? {
        for (l in lines) {
            val c = board[l[0]]
            if (c != ' ' && c == board[l[1]] && c == board[l[2]]) return l
        }
        return null
    }

    fun isFull(board: List<Char>): Boolean = board.none { it == ' ' }
}

object Rps {
    /** 0 = taş, 1 = kâğıt, 2 = makas. Sonuç: 0 berabere, 1 birinci kazanır, 2 ikinci kazanır. */
    fun result(a: Int, b: Int): Int {
        if (a == b) return 0
        return if ((a - b + 3) % 3 == 1) 1 else 2
    }
}

object Teams {
    fun split(players: List<String>, teamCount: Int, rnd: Random = Random.Default): List<List<String>> {
        require(teamCount >= 1) { "En az 1 takım gerekli" }
        require(players.isNotEmpty()) { "Oyuncu yok" }
        val n = minOf(teamCount, players.size)
        val shuffled = players.shuffled(rnd)
        val teams = List(n) { mutableListOf<String>() }
        shuffled.forEachIndexed { i, p -> teams[i % n].add(p) }
        return teams
    }

    fun teamCountForSize(playerCount: Int, perTeam: Int): Int =
        ceil(playerCount.toDouble() / perTeam.coerceAtLeast(1)).toInt().coerceAtLeast(1)
}

data class Pairing(val pairs: List<Pair<String, String>>, val leftOver: String?)

object Pairs {
    fun make(players: List<String>, rnd: Random = Random.Default): Pairing {
        val s = players.shuffled(rnd)
        val pairs = s.chunked(2).filter { it.size == 2 }.map { it[0] to it[1] }
        val left = if (s.size % 2 == 1) s.last() else null
        return Pairing(pairs, left)
    }
}

object Picker {
    fun pick(items: List<String>, used: Set<String>, noRepeat: Boolean, rnd: Random = Random.Default): String? {
        val pool = if (noRepeat) items.filter { it !in used } else items
        if (pool.isEmpty()) return null
        return pool[rnd.nextInt(pool.size)]
    }
}

object WheelMath {
    /** İşaretçi çarkın tepesinde (270°). Seçilen dilimin ortası işaretçiye gelecek dönüş açısını verir. */
    fun targetRotation(current: Float, index: Int, count: Int, rnd: Random = Random.Default): Float {
        val sweep = 360f / count
        val theta = (index + 0.5f + (rnd.nextFloat() - 0.5f) * 0.7f) * sweep
        val delta = (((270f - theta - current) % 360f) + 360f) % 360f
        return current + delta + 360f * 5
    }

    fun indexAt(rotation: Float, count: Int): Int {
        val sweep = 360f / count
        val theta = (((270f - rotation) % 360f) + 360f) % 360f
        return (theta / sweep).toInt() % count
    }
}

object Countdown {
    fun remaining(endAt: Long, now: Long): Long = maxOf(0L, endAt - now)

    fun format(ms: Long): String {
        val totalSec = (ms + 999) / 1000
        val m = totalSec / 60
        val s = totalSec % 60
        return (if (m < 10) "0$m" else "$m") + ":" + (if (s < 10) "0$s" else "$s")
    }
}

data class CustomGame(val name: String, val items: List<String>)

object Codec {
    private const val ITEM = '\u0001'
    private const val GAME = '\u0002'
    private const val NAME = '\u0003'

    fun clean(s: String): String = s.filter { it !in '\u0001'..'\u0004' }.trim()

    fun encodeList(list: List<String>): String = list.joinToString(ITEM.toString())

    fun decodeList(s: String): List<String> = if (s.isEmpty()) emptyList() else s.split(ITEM)

    fun encodeGames(games: List<CustomGame>): String =
        games.joinToString(GAME.toString()) { clean(it.name) + NAME + it.items.joinToString(ITEM.toString()) }

    fun decodeGames(s: String): List<CustomGame> {
        if (s.isEmpty()) return emptyList()
        return s.split(GAME).mapNotNull { g ->
            val parts = g.split(NAME, limit = 2)
            if (parts.size < 2 || parts[0].isBlank()) null
            else CustomGame(parts[0], decodeList(parts[1]))
        }
    }
}
